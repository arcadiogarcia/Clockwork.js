﻿var CLOCKWORKCONFIG = {
    enginefps: 60,
    animationfps: 60,
    appbar_buttonBackgroundColor: "yellow",
    appbar_buttonForegroundColor: "black",
    appbar_backgroundColor: "green",
    appbar_foregroundColor: "black",
    screenbuffer_width: 800,
    screenbuffer_height: 400
};
